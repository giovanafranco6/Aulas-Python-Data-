#Nesse programa vamos criar um simples grafico de linhas

import matplotlib.pyplot as plt 

# Criar um Figure a um conjunto Axes (area de pilotagem)

fig, ax = plt.subplots() 

# Dados para o grafico 
ax.plot([1, 2, 3, 4], [10, 42, 23, 35], linestyle='-.', marker='^', color='#b910bc') 

# Rotulos e titulos
ax.set_xlabel("Dias Inciais")
ax.set_ylabel("Notas")
ax.set_title("Grafico de Notas")

# Adiciona Grades 
ax.grid(True)



plt.show() 

