# Exercicio 2:
# Elabore um grafico de barras horizontais para comparar as inteções de votos dos eleitores para prefeito da cidade de Tiririca do Sul conforme dados abaixo:
# Cadidato - Percentual
#    Gaspar - 32
#    Luiza - 28
#    Jorge - 22
#    Anabela - 16
#    Nulos e Brancos - 2

#    Defina a cor para cada candidato respectivamente: red, blue, green, pink, gray
#    Título do Gráfico: Tiririca do Sul - Eleições 2026 \n Pesquisa de Intenção de Votos
#    Titulo eixo x: Percentual de votos
#    Título do Eixo Y: Candidatos


import matplotlib.pyplot as plt   

candidato = ['Gaspar', 'Luiza', 'Jorge', 'Anabela', 'Nulos e Brancos']
percentual = [32, 28, 22, 16, 2]

plt.figure(figsize=(9,6))
plt.barh(candidato, percentual, color=["red", "blue", "green", "pink", "gray"])

plt.title("˚⋆˚⋆˚  Tiririca do Sul - Eleições 2026 \n Pesquisa de Intenção de Votos ˚⋆˚⋆˚  ", color="#007464" )
plt.xlabel('Candidato', color="#007464")
plt.ylabel('Percentual', color="#007464")



plt.show()