#Nesse programa vamos solicitar ao usuario a entreda de 2 numeros
# e efetuar algumas aperaçoes artimeticas

numero1 = int(input("Digite um numero:"))
numero2 = int(input("Digite outro numero:"))

#Soma
soma = numero1 + numero2
print(f"A soma dos numeros: {soma}")

#Subtração

sub = numero1 - numero2
print(f"A Subtração dos numeros: {sub}")

#Multiplicação

mult = numero1 * numero2
print(f"A Multiplicação dos numeros: {mult}")

#Divisão
div = numero1 / numero2
print(f"A Divisão de {numero1} por {numero2} é {div}")

#Divisão Inteira

div_int = numero1 // numero2
print(f"A Divisão de {numero1} por {numero2} em numero inteiro é {div_int}")
#Resto da Divisão
resto = numero1 % numero2 
print(f"O Resto da Divisão de {numero1} por {numero2} é {resto}")

#Pootencia
potencia = numero1 ** numero2
print(f"{numero1} elevado a {numero2} é {potencia}")

#Porcentagem 
# O Python não possui um operador para calcular a porcentagem
# Devemos ultilizar a propria Matematica, calculando 10% de 500
valor = numero2 * (numero1 * 0.01)
print(f'{numero1}% de {numero2} é {valor}')

#Descontando 

valor_d = numero2 * (numero2 )


