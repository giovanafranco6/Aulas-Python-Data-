# Nesse Programa vamos verificar a menção final do aluno e determinar se o mesmo foi aprovado, reprovado ou ficou de recuperação 

mencao = input('Digite a Menção do Aluno(D, ED, ND): ')

if mencao.upper() == 'D':
    print()
    print('-' * 50)
    print('O Aluno esta desenvolvido na materia, portanto esta APROVADO')
    print('-' * 50)
    print()
elif mencao.upper() == 'ED':
    print()
    print('-' * 50)
    print('O ALuno esta em Desenvolvimento, portato esta de RECUPERAÇÃO')
    print('-' * 50)
    print()
elif mencao.upper() == 'ND':
    print()
    print('-' * 50)
    print('O Aluno esta não esta desenvolvido, portanto esta REPROVADO')
    print('-' * 50)
    print()
else:
    print()
    print('-' * 50)
    print('Menção Invalida')
    print('-' * 50)
    print()
    