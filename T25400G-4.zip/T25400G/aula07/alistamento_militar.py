# Nesse Programa vamos verificar se um jovem esta apto para fazer o alistamento militar 

print('=' * 50)
print('Exercito Brasileiro')
print('=' * 50)

nome = input('Digite seu Nome:')
idade = int(input('Digite sua idade:'))
sexo = input('Sexo: Digite (M) ou (F) para feminino: ')

if idade == 18:
    if sexo.lower() == 'm':
      print('-' * 50)
      print('Você esta apto ao serviço militar')
      print('Diriga-se a uma junta Militar')
      print('-' * 50)

print('=' * 50)
print('Sistema Militar')

