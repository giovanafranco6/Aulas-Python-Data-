# Nesse Programa vamos manipular as listas com comandos de alteração, inserção e remoção.


#Lista vazia de Frutas
frutas = []
frutas.append('Maçã')
print(frutas)

fruta = input('Digite sua Fruta Favorita: ')                #Adicionar um Novo Item no Final da LIsta
frutas.append(fruta)
print(frutas)

frutas.append('Banana')                                  
print(frutas)

frutas.insert(0, 'Acerola')                                #Escolher a posição de um Item na LIsta
print(frutas)

fruta = input('Digite outra Fruta: ')                      #Adicionar Novo Item em outra Posição da Lista
frutas.insert(3, fruta)
print(frutas)

frutas [1] = 'Pera'                                        #Substitur Item da Lista
print(frutas)

frutas.pop()                                               #Remover o Ultimo Item da Lista
print(frutas)

frutas.pop(0)                                             #Remover um Item da Lista e Escolher qual
print(frutas)

frutas.remove('Pera')
print(frutas)

