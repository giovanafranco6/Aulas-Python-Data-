# Nesse Progrma vamos trabalhar com o arquivo .CSV real para explorar a biblioteca Pandas

import pandas as pd 
import io 

df_vendas = pd.read_csv('vendas.csv')
print('                   :*・°☆ DataFrame ☆.。.:*')
print()
print(df_vendas)
print('=' * 50)
print()

# Exxercicio: Imprimir as estatisticas do DataFrame 
#Imprimir a vendas do iphone XS
#Imprimir as vendas de TV
#Criar uma coluna total da venda multiplicando o preço pela quantidade 
# Imprimir a Soma, Media, Maximo, Minimo, e Contagem do total da venda
# Imprimir data das vendas 



print('°• Vendas do iPhone XS °•')
iphone_xs = df_vendas[df_vendas['Produto'] == 'iPhone XS']
print(iphone_xs)
print('=' * 50)
print() 

print('°• Vendas da Televisão °•')
televisao = df_vendas[df_vendas['Categoria'] == 'Televisão']
print(televisao)
print('=' * 50)
print()




print('Vendas Total por Categoria ')
print('°• Vendas Totais por Produto °•')
df_vendas['ValorTotal'] = df_vendas['Preco'] * df_vendas['Quantidade']
print(df_vendas)
print('=' * 50)
print()


print('-' * 10)
print('°• Soma dos Produtos °•')
soma_produto = df_vendas.groupby('Produto')['ValorTotal'].sum()
print(soma_produto)
print('-' * 20)

print('°• Media dos Produtos °•')
media_produto = df_vendas.groupby('Produto')['ValorTotal'].mean()
print(media_produto)
print('-' * 20)

print('°• Maxima dos Produtos °•')
Maximo_produto = df_vendas.groupby('Produto')['ValorTotal'].max()
print(Maximo_produto)
print('-' * 20)

print('°• Minimo dos Produtos °•')
minimo_produto = df_vendas.groupby('Produto')['ValorTotal'].min()
print(minimo_produto)
print('-' * 20)

print('°• Numero de Vendas por Porduto °•')
numero_vendas = df_vendas.groupby('Produto')['ValorTotal'].count()
print(numero_vendas)
print('-' * 20)
print('=' * 50)



print('°• Filtro por Data °•')
df_vendas['DatVenda'] = pd.to_datetime(df_vendas['DataVenda'])
df_vendas.info()
print('-' * 20)
print()

print('°• Vendas em 10/01/2025 °•')
vendas_dia_01 = df_vendas[df_vendas['DatVenda'] == "2016-12-01"]
print(vendas_dia_01)
print('=' * 50)
print()


