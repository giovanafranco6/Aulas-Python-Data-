# Nesse programa vamos criar um arquivo texto usando a programação do Python
# o 'a' cria um arquivo novo. Se o arquivo existir, o mesmo sera aberto e o conteúdo é gravado no final dele

def gravar_texto (nome_arquivo, texto):
    
    with open (nome_arquivo, 'a', encoding= 'utf-8') as arquivo: 
        arquivo.write(texto + '\n')
        print('Conteúdo gravado com Sucesso')

nome_arquivo = 'texto2.txt'
texto = 'Quero ver você Bilhar'


gravar_texto(nome_arquivo, texto) 
