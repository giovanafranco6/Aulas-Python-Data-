# Nesse programa vamos ler o conteudo de um arquivo texto usando a programação do Python
# o 'r' abre um arquivo somente para leitura

def ler_arquivo(nome_arquivo):

    with open(nome_arquivo, 'r', encoding= 'utf-8') as arquivo:
        conteudo = arquivo.read()
        print(conteudo)

nome_arquivo = input('Digite o Nome do Arquivo:')
ler_arquivo(nome_arquivo)

