
def temperatura (celsius):
    fahrenheit = celsius * 9 / 5 + 32
    return fahrenheit


print()
print('--------Temperatura---------')
print()

celsius1 = float(input('Digite a Temperatura em Celsius:'))
calcular_temperatura = temperatura (celsius1)
print(f'Convertendo {celsius1} celsius para fahrenheit vira: {calcular_temperatura:.2f}')

print('='*50)




