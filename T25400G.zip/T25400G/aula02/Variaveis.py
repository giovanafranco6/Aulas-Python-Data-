#Nesse programa vamos estudar o uso de variaveis dentro do Python 

#variaveis para texto (String)
nome_usuario = 'Cruzeiro Maior de Minas'
cidade = 'Minas Gerais'

#Variavel para numeros inteiros
idade = 16

#Variavel para numeros decimais (Float)
altura = 1.75

#Variavel para valores booleanos (Bool)
esta_chovendo = False   #Falso
eh_aluno = True         #Verdadeiro

#Constantes são variaveis imutaveis
pi = 3.14159

#Imprimir o conteudo das variaveis
print("=========")
print()
#f-string
print( f'O nome do usuario é {nome_usuario}')
print(f'Ele tem {idade} anos')
print(f"mede{altura}")
print()
