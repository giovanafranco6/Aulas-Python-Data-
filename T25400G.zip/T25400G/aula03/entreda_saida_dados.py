# Nesse programa vamos estudar a Entreda de numeros usando a função input()
# e convertendo essa entreda pra numeros
#A função input() sempre recebe uma string (texto) mesmo que o numero seja digitado

print('='*50)
print('----------Mesclando 2 Numeros---------')
numero1 = input('Digite um numeor:')                   
numero2 = input('Digite outro numero:')
soma = numero1 + numero2
print(f'Valor da soma: {soma}')

print('='*50)

print('='*50)
print('----------Somando 2 Numeros---------')
numero1 = int(input('Digite um numeor:'))                  # o int() deixa o texto como numero 
numero2 = int(input('Digite outro numero:'))
soma = numero1 + numero2
print(f'Valor da soma: {soma}')


print('='*50)
print('----------Somando 2 Numeros Decimais---------')
numero1 = float(input('Digite um numero decimal:'))        # o float() deixa calcular numeros decimais
numero2 = float(input('Digite outro numero decimal:'))
soma = numero1 + numero2
print(f'Valor da soma: {soma}')