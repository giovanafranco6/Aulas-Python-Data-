# Nesse Programa vamos estudar o Fatiamento de Lista 
# Nesse caso podemos acessar alguns elementos da lista determinando o indice de inicio e o final

#Lista de Temperaturas Medias na semana
tempetarutas = [22, 25, 27, 30, 26, 24, 23]

# Imprimindo a Lista completa
print('------Temperaturas Medias na semana------')
print(f'Temperaturas: {tempetarutas}')

print('='*50)

# Imprimindo os 3 primeiros dias
print(f'3 Primeiros dias: {tempetarutas [0:3]}')

print('='*50)

# Imprimindo da 2 ate a 4 temperatura
print(f'Da 2 a 4 temperatura: {tempetarutas [1:4]}')

print('='*50)

# Imprimindo as 3 ultimas temperaturas
print(f'3 Ultimos dias: {tempetarutas [4:]}')

print('='*50)

# Imprimindo dia sim e dia não
print(f'Temperaturas Alternadas: {tempetarutas [::2]}')

print('='*50)

# Imprimindo a Lista Invertida
print(f'Lista Invertida: {tempetarutas [::-1]}')

print('='*50)

# Imprimindo ultima temperatura
print(f'Ultima temperatura: {tempetarutas [-1]}')

print('='*50)



