# Nesse Programa vamos verificar se um numerio é par ou impar

numero = int(input('Digite um numero inteiro:'))

if numero %2 == 0:
    print(f'{numero} é PAR')
else:
    print(f'{numero} é IMPAR')

