# Nesse Programa vamos calcular a idade de uma pessoa

import datetime
data_atual = datetime.date.today()
print(data_atual)
ano_atual = data_atual.year 
print('=' * 50)
print('Escola Senai')
print('=' * 50)

nome = input ('Digite seu Nome: ')

ano_nascimento = int(input('Digite o ano do seu nascimento:'))

idade = ano_atual - ano_nascimento

resposta = input ('Você já fez aniversario essa ano? S/N:' )
if resposta.upper() == 'N':                         # .upper() converte todas as letras para maiuscula 
    idade -= 1                                      # equivale a idade = iade -1

print(f'{nome}, você tem {idade} anos')




