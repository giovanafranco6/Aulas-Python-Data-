numeros = [10, 20, 30, 40, 50]

numeros.append(60)
print(numeros)

numeros.insert(2,25)
print(numeros)

numeros.remove(10)
numeros.remove(40)
print(f'Lista após a Remoção: {numeros}')

print('------Lista Completa------')
print(numeros)


print('=' * 50)

cores = []

cor = input('Digite uma Cor: ')               
cores.append(cor)

cor = input('Digite outra Cor: ')               
cores.append(cor)

cor = input('Digite outra Cor: ')               
cores.append(cor)


print('------Lista de Cores------')
print(cores)

print('=' * 50)

letras = [ 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H']

print('------Lista de Letras------')
print(letras)

print(f'3 Primeiras Letras: {letras [0:3]}')
print(f'3 Ultimas Letras: {letras [5:]}')
print(f'2 Letras do Meio: {letras [3:5]}')

print('=' * 50)


