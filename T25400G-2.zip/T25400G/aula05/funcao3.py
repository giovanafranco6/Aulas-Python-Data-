# Nesse Programa vamos estudar funções sem argumento e com retorno 

import random

def sortear_numero ():
    numero_sorteado = random.randint(1,60)
    return numero_sorteado 

print('---------Loterica Sorte Certa---------')
print('Sorteio no bolão da MegaSena')

numero1 = sortear_numero ()
print(f'Numero sorteado: {numero1}')

numero2 = sortear_numero ()
print(f'Numero sorteado: {numero2}')

numero3 = sortear_numero ()
print(f'Numero sorteado: {numero3}')

numero4 = sortear_numero ()
print(f'Numero sorteado: {numero4}')

numero5 = sortear_numero ()
print(f'Numero sorteado: {numero5}')


numeros = numero1, numero2, numero3, numero4, numero5
print(f'------Conjunto de todos os Numeros------ ')
print(numeros)
