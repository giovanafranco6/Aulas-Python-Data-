# Nesse programa vamos estudar funções sem argumento e sem retorno 

def linha (): 
    # Imprimir 50 vezes '='
    print('=' * 50)
    print()

print('Primeiro Programa sobre Funções')
linha()    
nome = input('Digite seu Nome:')
linha()

idade = input('Digite sua Idade:')
linha()

print(f'{nome}, você tem {idade} anos')
linha()

