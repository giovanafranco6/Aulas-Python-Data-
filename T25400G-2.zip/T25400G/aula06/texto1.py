# Nesse programa vamos criar um arquivo texto usando a programação do Python
# 'w' cria um arquivo novo para receber um conteúdo 

def gravar_texto_em_arquivo(nome_arquivo, texto):

    with open(nome_arquivo, 'w') as arquivo: 
        arquivo.write(texto)
        print('Arquivo criado com Sucesso')



nome_do_arquivo = 'texto1.txt'
conteudo_do_arquivo = 'Batatinha quando nasce, espalha rama peo chão. Meninha quando dorme põe a mão no coração'


gravar_texto_em_arquivo(nome_do_arquivo, conteudo_do_arquivo)

