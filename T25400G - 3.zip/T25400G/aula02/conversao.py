#Nesse programa vamos estudar a conversão de dados em Python
#A conversão pertime alterar o tipode dados de uma variavel 
#para outro tipo de dados. Por exemplo, uma variavel do tipo texto
#pode ser convertido para numero, desde que seu valor seja um
#numero
#Idade = "18" -> Essa variavel, apesar de ser um numero, ela é considerada um texto pelo Python 
#como texto (string), pois o numero se encontra entre
#aspas. Para converter essa variavel para numero usamos a função int()


idade_str = "18"

print(f'A variavel idade_str é o tipo {type(idade_str)}')
      
idade_int = int(idade_str) 
print(f'A variavel idade_int é do tipo{type(idade_str)}')

soma = idade_int + 10

print(f"Resultado: {soma}")






