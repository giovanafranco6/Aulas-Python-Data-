#Nesse programa vamos simular um cadastro de um aluno para um curso

print("=" * 50 ) #Imprimi 50 vezes o sinal de =
nome_escola = 'Senai Celso Charuri'
print(nome_escola)
print("=" * 50)
print("•❀ Cadastro de Alunos===")
print("=" * 50)
nome_aluno = input("Digite o Nome do Aluno:") 
idade = input("Digite a Idade do Aluno:")
curso = input("Digite o Curso Pretendido pelo aluno:")
print("=" * 50)
print("Confirme os dados do Aluno")
print( f'Nome: {nome_aluno}')
print(f'Idade: {idade}')
print(f'Curso: {curso}')
print("=" * 50)


