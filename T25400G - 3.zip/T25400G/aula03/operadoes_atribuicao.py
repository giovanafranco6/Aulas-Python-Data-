# Os Operadores de Atribuição Combinam uma Operação aritimetica com a atribuição do valor
# Exemplo: soma += 1

numero = 5
print(numero)

# Adicionando 5 a variavel numero sem usar o operador de atribuição 
numero = numero + 5
print(f'Novo valor de numero: {numero}')


# Operador de Adição e Atribução

numero += 5          # Equivalente á numero = numero + 5      
print(f'Novo valor de numero: {numero}')


#Operador de Subtração e Atribuição

numero -= 8          # Equivalente á numero = numero - 8
print(f'Valor de numero menos 8: {numero}')


# Operador de Multiplicação e Atribuição

numero *= 10         # Equivalente á numero = numero * 10
print(f'Valor de numero * 10: {numero}')


# Operador de Divisão e Atribuição
 
numero /= 2         # Equivalente á numero = numero / 2
print(f'Valor de numero dividido por 2: {numero}')

