# Nesse Programa vamos verificar a idade de uma pessoa para tirar a carteira de motorista

idade = int(input('Digite sua idade: '))

if idade >= 18:
    print('-' * 50)
    print('Você pode tirar a carteira e motorista')
    print('-' * 50)
else:
    print('-' * 50)
    print('Você é muito piralho pra tirar a carteira de motorista')
    print('-' * 50)
