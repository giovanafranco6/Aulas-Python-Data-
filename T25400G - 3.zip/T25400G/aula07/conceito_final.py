# Nesse Programa vamos receber 3 notas entre 0 e 100, calcular a media e verificar se o aluno esta: aprovado ou reprovado
# Para ser aprovador, o aluno precisa de media igual ou superior a 50

print('=' * 50)
print('Escola Senai')
print('=' * 50)

nome = input ('Digite seu nome : ')
nota1 = float(input('Digite a 1ª nota:'))
nota2 = float(input('Digite a 2ª nota:'))
nota3 = float(input('Digite a 3ª nota:'))
media = (nota1 + nota2 + nota3) /3

if media >= 50:
    print()
    print('-' * 50)
    print(f'{nome} esta APROVADO')
else:
    print()
    print('-' * 50)
    print(f'{nome} esta REPROVADO')

print()
print('-' * 50)
print(f'{nome}, sua media foi {media:.1f}')
print('-' * 50)


