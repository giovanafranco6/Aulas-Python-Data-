# Nesse Programa vamos estudar funções com argumento e sem retorno 

#Função para somar 2 numeros
def somar(num1, num2):
    resultado = num1 + num2
    resultado = float (resultado)
    print(f'A soma de {num1} + {num2} = {resultado}')
    print('=' * 50)

# Programa Principal

numero1 = float(input(f'Digite um Numero: '))
numero2 = float(input(f'Digite outro Numero: '))

somar(numero1, numero2)

