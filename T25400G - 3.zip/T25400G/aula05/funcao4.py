# Nesse Programa vamos estudar funções com argumento e com retorno 


import math

# Função para calcular area de um retangulo/quadrado
def calcular_area_retangulo (base, altura):
    area = base * altura
    return area



# Função para calcular area de um circulo
def calcular_area_circulo (raio):
    area = math.pi * raio **2
    return area 



def linha():
    print()
    print('=' * 50)




print('--------Calcule a Area de um Retangulo/Quadrado----------')
base_retangulo = float(input(f'Digite a Base:'))
altura_retangulo = float((input(f'Digite a Altura:')))

print(f'Essa é a Area do Retangulo/Quadrado:{calcular_area_retangulo(base_retangulo, altura_retangulo)}')

linha()

print('--------Calcule a Area de um Circulo------------')
raio = float(input(f'Digite o raio do circulo:'))

print(f'Essa é a Area do Circulo: {calcular_area_circulo (raio):.2f}')

linha()

print('---------Fim------------')

