import seaborn as sns
import matplotlib.pyplot as plt

# Carregar os Dados do Seaborn 

iris = sns.load_dataset('iris')
print(iris)

# Calculando a Matriz de Corelação
# Método .corr() : calcula a Relação entre Variaveis do ponto de -1 a 1
# Selecionamos apenas as colunas numéricas para o calculo 

correlacao= iris.drop(columns='species').corr()

plt.figure(figsize=(8, 6))

sns.heatmap(
    correlacao, 
    annot=True,      # Adiciona os valores numéricos dentro dos quadrados
    fmt=".2f",       # Formata para 2 casas decimais
    cmap='coolwarm', # Escala de cor (Azul para frio/negativo, Vermelho para quente/positivo)
    linewidths=0.5   # Adiciona uma linha fina entre os quadrados
)


plt.title('Matriz de Correlação - Dataset Iris ', fontsize=16)

plt.show()