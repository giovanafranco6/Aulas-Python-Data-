import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

data = { 
    'Mes' :['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez'],
    'Vendas' : [1500, 1000, 2200, 2500, 2100, 2800, 3100, 2900, 3500, 3800, 3100, 4500],
    'Volume' : [50, 65, 80, 90, 75, 110, 120, 105, 135, 150, 113, 200],
    'Margem' : [0.15, 0.10, 0.20, 0.19, 0.17, 0.22, 0.25, 0.23, 0.26, 0.28, 0.24, 0.32],
    'Filial' : ['SP', 'RJ', 'SP', 'MG', 'RJ', 'SP', 'MG', 'RJ', 'SP', 'MG', 'RJ', 'SP' ]    
}

df = pd.DataFrame(data)

# Gráfico de Linhas (Tendência Mensal)
plt.figure(figsize=(10, 6))

# Plotar os Dados
plt.plot(
    df['Mes'],
    df['Vendas'],
    marker= 'o',
    linestyle='-',
    color='green',
    label='Vendas Totais'
)

# Títulos e Formatações 
plt.title('Tendência de Vendas Mensais', fontsize=16)
plt.xlabel('Mêses', fontsize=12)
plt.ylabel('Valor Total de Vendas', fontsize=12)
plt.grid(True, linestyle='--', alpha=0.6)
plt.legend()

# Salvando o Gráfico em arquivo png
plt.savefig('Tendência_Vendas.png')




# Gráfico de Colunas (Comparação Categórica)
plt.figure(figsize=(10, 6))
plt.bar(
    df['Mes'],
    df['Volume'],
    color=['gray', 'blue', 'gray', 'blue', 'gray', 'blue', 'gray', 'blue', 'gray', 'blue', 'gray', 'blue']
)

plt.title('Volume de Unidades Vendidas Mensais', fontsize=16)
plt.xlabel('Mêses', fontsize=12)
plt.ylabel('Unidades Vendidas', fontsize=12)

# Adiciona Rotulo de Dados em cima das Colunas
for i in range(len(df['Mes'])):
    plt.text(i, df['Volume'][i] + 3, str(df['Volume'][i]), ha='center')

plt.savefig('Volume_Colunas.png')


# Gráfico de Dispersão (Relação entre Variáveis)
plt.figure(figsize=(8, 8))
plt.scatter(
    df['Volume'],
    df['Vendas'],
    c='purple',
    s= df['Margem'] * 2000,
    alpha=0.7
)

plt.title('Relação entre Volume e Vendas', fontsize=16)
plt.xlabel('Unidades Vendidas', fontsize=12)
plt.ylabel('Volar das Vendas', fontsize=12)


plt.show()