import seaborn as sns
import matplotlib.pyplot as plt

#  Carregando os dados
df_tips = sns.load_dataset('tips')

#  Configurando o estilo
sns.set_theme(style="darkgrid")

#  Criando o gráfico combinado (Histograma + KDE)
plt.figure(figsize=(10, 6))

sns.histplot(
    data=df_tips, 
    x='tip', 
    kde=True,       # Adiciona a linha de densidade suave
    color='teal',   # Cor estilizada
    bins=20         # Define em quantos intervalos dividir os dados
)

#  Personalizando o gráfico
plt.title('Distribuição dos Valores de Gorjetas', fontsize=15)
plt.xlabel('Valor da Gorjeta ($)', fontsize=12)
plt.ylabel('Frequência (Contagem)', fontsize=12)

plt.show()