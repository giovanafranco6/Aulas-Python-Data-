import seaborn as sns
import matplotlib.pyplot as plt

# Carregar o dataset interno do Seaborn 

df_tips = sns.load_dataset('tips')
print(df_tips)

# Configurando o Estilo Visual 
sns.set_theme(style='whitegrid')

# Criando o Boxplot
# x: Categoria (Dia da Semana)
# y: Variavel Numeirca (Valor total da compra)
plt.figure(figsize=(10, 6))
sns.boxplot(
    data=df_tips,
    x='day',
    y='total_bill',
    palette='Set2'
)

plt.title('Distribuição do Valor das Contas por Dia da Semana', fontsize=16)
plt.xlabel('Dia', fontsize=12)
plt.ylabel('Valor Total da Comptra', fontsize=12)

plt.show()

