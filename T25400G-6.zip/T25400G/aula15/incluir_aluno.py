# Nesse programa vamos conectar ao banco de dados e cadastrar alguns alunos

import sqlite3

# Conectar ao bando 
conn = sqlite3.connect("curso.db")
cursor = conn.cursor()

while True:
    nome = input('Digite o nome do aluno: ')
    idade = input('Digite a idade do aluno: ')
    curso = input('Digite o curso do aluno: ')
    cpf = input('Digite o CPF do aluno: ')

    # Inserindo dados no banco 
    cursor.execute("INSERT INTO alunos(nome, idade, curso, cpf) VALUES(?, ?, ?, ?)", (nome, idade, curso, cpf) )
    # Salva as alteraçoes do Banco 
    conn.commit() 

    resposta = input('deseja cadastrar outro aulo? S/N')
    if resposta.upper() == "N": 
        break

conn.close()

print('Dados gravados com Sucesso')


