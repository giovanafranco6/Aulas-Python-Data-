# Nesse programa vamos consultar os alunos da tabela de alunos

import sqlite3


conn = sqlite3.connect('curso.db')
cursor = conn.cursor()

# Selecionando todos os alunos
cursor.execute('SELECT *FROM alunos')
alunos = cursor.fetchall() # Cria uma matriz co todas as colunas e todas as linhas 

print('=' * 30)
print('Nome     Idade     Curso     CPF')
print('=' * 30)

for aluno in alunos:
    print(f'{aluno[1]}      {aluno[2]}     {aluno[3]}      {aluno[4]}')

conn.close
print('=' * 30)



