# Nesse programa vamos alterar os dados da tabela de alunos

import sqlite3


conn = sqlite3.connect('curso.db')
cursor = conn.cursor()

cpf_busca = input('Digite o CPF do aluno que quer alterar')

cursor.execute('SELECT * FROM alunos WHERE cpf = ?', (cpf_busca,)) 
aluno = cursor.fetchone()

if aluno:
    print('Registro Encontrado')
    print(f'Nome: {aluno[1]}, idade: {aluno[2]}, Curso: {aluno[3]}, CPF: {aluno[4]}')

    print('*' * 30)

    print('Digite os novos dados ou enter para nao alterar')
    novo_nome = input(f'Novo nome:[{aluno[1]}]:') or aluno[1]
    nova_idade = input(f'Nova idade:[{aluno[2]}]:') or aluno[2]
    novo_curso = input(f'Novo curso:[{aluno[3]}]:') or aluno[3]

    # Convertendo idade pra INT
    nova_idade = int(nova_idade)

    cursor.execute('UPDATE alunos SET nome = ?, idade = ?, curso = ? Where cpf = ?', (novo_nome, nova_idade, novo_curso, cpf_busca))
    conn.commit()

    print('Dados alterados com Sucesso')

else:
    print('CPF nao cadastrado')

conn.close()