# Nesse Programa vamos fazer a conexao com o Banco de Dados SQLite e criar a primeira tabela 

import sqlite3 

# Conectar ao Banco de Dados (ou criar se nao existir)

conn = sqlite3.connect("curso.db")
cursor = conn.cursor()

# Criar Tabela 
cursor.execute('''
        CREATE TABLE IF NOT EXISTS alunos (
               id_aluno INTEGER PRIMARY KEY,
               nome TEXT NOT NULL,
               idade INTEGER,
               curso TEXT,
               cpf TEXT NOT NULL
               )
               ''')

# Fechar a Conexao 
conn.close()
print('Operação Realizada com Sucesso')
