# IMC é o indice de massa corporal que mede se uma pessoa esta com seu peso ideal.
# Crie um programa que solicita ao usuario o seu peso em quilos (exemplo: 65.5)
# e sua altura em metros (exemplo: 1.75)
# Calcule e imprima no console o IMC dessa pessoa com uma casa decial
# Formula para calcular o IMC 


altura = float(input('Digite sua Altura (m):'))
peso =  float(input('Digite seu Peso (kg):'))
imc = peso / altura ** 2 

print(f'Seu IMC é: {imc:.1f}')         # Esse ".1f" é para colocar so 1 numero depois da ","
