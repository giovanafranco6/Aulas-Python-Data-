# Nesse programa vamos estudar listas simples e tridimencionais 

temperaturas_semana = [25, 20.4, 18, 14, 19, 22, 20]

# Lista de responsaveis para sexta, sabado e domingo. Responsavel, 1 Suplente e 2 Suplente

 # Lista tridimensional em Python 

lista_responsavel= [ 
    ['Gaspar', 'Anabela', 'Jorge'], 
    ['Anabela', 'Luiza', 'Galego'], 
    ['Jorge', 'Galego', 'Luiza'] ]

print(f'Temperaturas da Semana:{temperaturas_semana}')
print(f'Temperatura da Segunda-Feira:{temperaturas_semana[0]}')
print(f'Temperatura do Sabado:{temperaturas_semana[5]}')

print(f'Responsaveis pelo restaurante:\n {lista_responsavel}')
print(f'Responsavel pela Sexta Feira:{lista_responsavel[0][0]}')
print(f'1 Suplente de Sabado:{lista_responsavel[1][1]}')
print(f'Responsavel pelo Domingo:{lista_responsavel[2][0]}')
