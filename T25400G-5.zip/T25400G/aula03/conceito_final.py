# Nesse programa vamos receber 4 notas de um aluno, armazenar em um vetor (lista), e calcular a media das nota

print('⋆.ೃ࿔*:･ Escola Senai ⋆.ೃ࿔*:･')
print('=' * 50)

notas= []

nota = float(input('Digite a primeira nota:'))
notas.append(nota)

print(f'Nota Adicionada. Nota:{notas}')
nota = float(input('Digite a Segunda nota:'))
notas.append(nota)

print(f'Nota Adicionada. Notas:{notas}')
nota = float(input('Digite a Terceira nota:'))
notas.append(nota)

print(f'Nota Adicionada. Notas:{notas}')
nota = float(input('Digite a Quarta nota:'))
notas.append(nota)
print(f'Nota Adicionada. Notas:{notas}')

soma_notas = sum (notas)                            # sum, Soma os itens de uma lista
print(f'Soma das Notas:{soma_notas}')
media = soma_notas / len(notas)                     # len, Conta quantos itens tem uma lista
print(f'A Media das Notas é:{media}')


notas[3] = 0                                        # Alterar um item da lista

print(f'Maior Nota: {max(notas)}')
print(f'Menor Nota: {min(notas)}')
