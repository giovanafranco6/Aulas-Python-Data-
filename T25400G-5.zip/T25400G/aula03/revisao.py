# Revisao de operadores aritimericos 


num1= 13
num2= 29

soma = num1 + num2
sub = num1 - num2
mult = num1 * num2
div = num2/num1
div_int = num2 // num1     #Essa divisao elimina os numeros depois da virgula
resto = num2 % num1        # Retorna o resto da divisão 
potencia = num1 ** 2       # Eleva o Primeiro numero ao Segundo Numero 

print(f'Soma:{soma}')
print(f'Subtração:{sub}')
print(f'Multiplicação:{mult}')
print(f'Divisão:{div}')
print(f'Divisão inteira:{div_int}')
print(f'Resto:{resto}')
print(f'potencia:{potencia}')
