# Nesse Programa vamos receber as notas de alguns alunos e calcular a media das notas

print('=' * 30)
print('-----Senai Celso Charuri-----')
print('=' * 30)

notas = []
nota = float(input('Digite a uma nota: '))
notas.append(nota)
nota = float(input('Digite a uma nota: '))
notas.append(nota)
nota = float(input('Digite a uma nota: '))
notas.append(nota)
nota = float(input('Digite a uma nota: '))
notas.append(nota)

print(f'Essas foram as notas do Aluno: {notas} ')

#somando os valores da lista
soma_notas= sum(notas)
media_notas = soma_notas / len(notas)

print(f'E essa doi a MEdia dele: {media_notas:.1f}')


