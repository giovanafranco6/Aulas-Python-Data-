# Nesse programa vamos trabalhar com Listas (vetores)


#Lista de Notas
notas = [10, 8, 6.5, 9]

#Lista de nome
gatos = ['Gaspar', 'luiza', 'Galego', 'Blue']

#Lista Mista
dados_aluno = [ 'Jorge Branco', 75, 1.70, True]

print('\n----------Lista de Notas--------------')
print(f'Segunda Nota: {notas [1]}')

print('\n----------Relação de Gatos--------------')
print(f'Primeiro Gato: {gatos [0]}')

print('\n----------Dados Aluno--------------')
print(f'Nome do Aluno: {dados_aluno[0]}')
print(f'Peso do Aluno: {dados_aluno[1]}')
print(f'Altura do Aluno: {dados_aluno[2]}')
print(f'Aluno Ativo: {dados_aluno[3]}')







