# Nesse Programa vamos estudar Matrizes. Uma Matriz é uma Lista com outras Listas separadas por linhas, com cada linha representando uma linha


# Matriz de Vendas dos 3 Vendedores nos ultimos 4 meses
print('-------Lista das Vendas dos 3 Vendedores nos Últimos 4 Meses-------')
vendas = [
    [100, 150, 110, 180],
    [90, 140, 120, 170],
    [110, 160, 130, 190]
]
print(vendas)

print('=' *50)

print(f'Vendas do Gaspar: {vendas [0]} ')

print('=' *50)

print(f'Vendas da Luiza do Segundo Mês: {vendas [1][1]} mil reais')

print('=' *50)

media_vendedor1 = sum(vendas [0]) / len(vendas[0])
media_vendedor2 = sum(vendas [1]) / len(vendas[1])
media_vendedor3 = sum(vendas [2]) / len(vendas[2])

print(f'Media das Vendas do Gaspar: {media_vendedor1:.2f}')
print(f'Media das Vendas da Luiza: {media_vendedor2:.2f}')
print(f'Media das Vendas do Jorge: {media_vendedor3:.2f}')

print('=' *50)

soma_vendas = sum(vendas[0]) + sum(vendas[1]) + sum(vendas[2])
meses = len(vendas[0])
media_vendas = soma_vendas / meses

print(f'Media das Vendas: {media_vendas:.2f}')

print('=' *50)

