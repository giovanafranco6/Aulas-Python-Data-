# Nesse Programa vamos estudar o escopo de uma variavel dentro do Programa. Uma Variavel fora de qualquer função é considerada uma variavel Global,
#ou seja, ela é visivel em todo Programa, uma variavel declarada dentro de uma função é considerada uma variavel Local, ou seja, ela é visivel apenas dentro da função.

salario_base = 50.00

def calcular_salario_horista (horas): 
    salario_final= horas * salario_base
    return salario_final

def calcular_salario_mensalista (desconto_faltas):
    salario_final = salario_base * 220 - desconto_faltas
    return salario_final

def calcular_salario_vendedor (valor_comissao):
    salario_final = salario_base * 50 + valor_comissao
    return salario_final

print()
print('--------Horista---------')
print()

funcionario_horista = input('Digite o Nome do funcionario Horista:')
horas_trabalhadas = int(input('Quantas horas ele trabalhou?:'))
calcular_salario_horista = calcular_salario_horista (horas_trabalhadas)
print(f'O Salario do {funcionario_horista} é de {calcular_salario_horista:.2f}')

print()
print('--------Mensalista---------')
print()

funcionario_mensalista = input('Digite o Nome do funcionario Mensalista:')
dias_faltas = int(input('Quantas faltas ele teve?:'))
valor_faltas = dias_faltas * 100
calcular_salario_mensalista = calcular_salario_mensalista (valor_faltas)
print(f'O Salario do {funcionario_mensalista} é de {calcular_salario_mensalista:.2f}')

print()
print('--------Vendedor---------')
print()

funcionario_vendedor = input('Digite o Nome do Vendedor:')
vendas = int(input('Digite o valor da comissão?:'))
calcular_salario_vendedor = calcular_salario_vendedor (vendas)
print(f'O Salario do {funcionario_vendedor} é de {calcular_salario_vendedor:.2f}')

print('='*50)

