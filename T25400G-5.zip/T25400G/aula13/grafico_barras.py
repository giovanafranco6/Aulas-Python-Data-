import matplotlib.pyplot as plt   

categorias = ['Eletronicos', 'Roupas', 'Alimentos', 'Livros']
vendas = [15000, 10000, 20000, 8000]

plt.figure(figsize=(8,5))
plt.barh(categorias, vendas, color=["skyblue", "gold", "lightcoral", "green"])

plt.title("Vendas Totais por Categorias")
plt.xlabel('Produto')
plt.ylabel('Quantidade de Vendas')



plt.show()