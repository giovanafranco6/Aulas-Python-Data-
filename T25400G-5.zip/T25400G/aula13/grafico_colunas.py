import matplotlib.pyplot as plt   

categorias = ['Eletronicos', 'Roupas', 'Alimentos', 'Livros']
vendas = [15000, 10000, 20000, 8000]

plt.figure(figsize=(8,5))
plt.bar(categorias, vendas, color=["#90e0e6", "#56be79", "#7e56be", "#be5d56"])

plt.title("Vendas Totais por Categorias")
plt.xlabel('Produto')
plt.ylabel('Quantidade de Vendas')



plt.show()