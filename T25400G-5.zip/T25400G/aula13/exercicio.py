
# Exercício:
# Faça um grafico de linhas comparando as vendas do 1º semestre de 2025 conforme dados abaixo:
#    Janeiro: 120000
#    Fevereiro: 150000
#    Março: 180000
#    Abril: 160000
#    Maio: 200000
#    Abril: 230000

#    Defina os marcadores (marker) do tipo triângulo "^".
#    Escolha uma cor para a linha.
#    Defina o estilo de linha como 'dashdot'.
#    Não esqueça das linhas de grade



import matplotlib.pyplot as plt  

mes = ['Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho']
quantidade = [12000, 15000, 18000, 16000, 20000, 23000]


plt.figure(figsize=(8,5))
plt.plot(mes, quantidade, linestyle= 'dashdot', marker= '^', color='#5c0f8f' )

plt.title("°❀⋆*:°❀⋆* Quatidade Vendida no 1° Semestre de 2025 °❀⋆*:°❀⋆*", color='#5c0f8f')
plt.xlabel('Mês', color='#5c0f8f')
plt.ylabel('Quantidade', color='#5c0f8f')

plt.grid(True)

plt.show()