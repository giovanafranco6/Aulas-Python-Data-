# Nesse Programa vamos verificar o aluno é menor de idade

print('=' * 50)
print('Escola Senai')
print('=' * 50)
nome_aluno = input ('Digite o nome do aluno: ')
idade = int(input ('Digite a idade do aluno: '))

if idade < 18: 
    print ('Seus pais ou responsável deve estar para a matricula')

print('Diriga-se ao balcão da secretaria para matrícula no curso')
