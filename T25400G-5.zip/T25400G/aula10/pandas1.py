# Nesse programa vamos conhcer as funcoes basicas da biblioteca Pandas

import pandas as pd
import io 

# Simulando a leitura de um arquivo CSV
csv_data = """Produto,Categoria,Preco,Quantidade,DataVenda
Notebook,Eletrônicos,2500.00,1,2025-01-10
Mouse,Acessórios,50.00,2,2025-01-10
Teclado,Acessórios,120.00,1,2025-01-11
Monitor,Eletrônicos,800.00,1,2025-01-11
Fone de Ouvido,Acessórios,80.00,3,2025-01-12
Webcam,Eletrônicos,150.00,1,2025-01-12
Notebook,Eletrônicos,2600.00,1,2025-01-13
Impressora,Eletrônicos,400.00,1,2025-01-13
"""

df_vendas = pd.read_csv(io.StringIO(csv_data))
print('•❀.•❤•. DataFrame Original .•❤•.❀•')
print(df_vendas)
print('=' * 50)
print()

# Visualizando as primeiras linhas do DataFrame
print('•❀.•❤•. Primeiras Linhas do Dataframe .•❤•.❀•')
print(df_vendas.head())
print('=' * 50)
print()

# Visualizando as ultimas linhas do DataFrame
print('⋆.ೃ࿔*:･ Ultimas Linhas do Dataframe ⋆.ೃ࿔*:･')
print(df_vendas.tail())
print('=' * 50)
print()

# Visualizando informaçoes do DataFrame (tipo de dados e valores nao nulos)
print('❀⋆ Informações do DataFrame ⋆❀')
print(df_vendas.info())
print('=' * 50)
print()

# Visualizando a estatistica dos dados Numericos
print('·̇·̣̇̇·̣̣̇·̣̇̇·̇ •❣•୨୧ Estatística Descritiva ୨୧•❣• ·̇·̣̇̇·̣̣̇·̣̇̇·̇')
print(df_vendas.describe())
print('=' * 50)
print()

# Visualizando uma coluna especifica (serie)
print('≪ °❈ Coluna Produto ❈° ≫')
print(df_vendas["Produto"])
print('=' * 50)
print()

# Visualizando os dados filtrados: Categoria Eletronicos
print('♥´¨`•..♫ Vendas de Eletronicos ♫´¨`*•.¸¸♥')
eletronicos = df_vendas[df_vendas['Categoria'] == 'Eletrônicos']
print(eletronicos)
print('=' * 50)
print()

# Criar uma Coluna nova com o valor total de cada linha
print('♥•.... DataFrame com o Valor Total •.¸¸♥')
df_vendas['ValorTotal'] = df_vendas['Preco'] * df_vendas['Quantidade']
print(df_vendas)
print('=' * 50)
print()

# Agrupando dados: Vendas Total por Categoria
print('°°••....⫷ Vendas Total por Categoria ⫸..••°°°°••')
vendas_por_categoria = df_vendas.groupby('Categoria')['ValorTotal'].sum()
print(vendas_por_categoria)
print('=' * 50)
print()

# Converter a coluna "DataVenda" para o tipo datetime
print('꒷꒦˚︶˚︶︶꒷꒦ Filtro por Data ꒷꒦˚︶˚︶︶꒷꒦')
df_vendas['DatVenda'] = pd.to_datetime(df_vendas['DataVenda'])
df_vendas.info()
print('=' * 50)
print()

# Vizualizando Vendas por Data
print('˚︶˚ Vendas em 10/01/2025 ˚︶˚')
vendas_dia_10 = df_vendas[df_vendas['DatVenda'] == "2025-01-10"]
print(vendas_dia_10)
print('=' * 50)
print()

# Vizualizando em ordem de Preço do Menor para o Maior
print('•❤•.❀• DataFrame Ordenado pelo Preço •❤•.❀•')
df_ordenado_preco = df_vendas.sort_values(by = 'Preco')
print(df_ordenado_preco)
print('=' * 50)
print()

# Vizualizando em ordem de Produto de A a Z
print('❀• Produtos por ordem Alfabetica ❀•')
df_ordenado_produto = df_vendas.sort_values(by = 'Produto', ascending=False)
print(df_ordenado_produto)
print('=' * 50)
print()

# Vizualizando a Soma, Media, Valor MAximo, Valor Minimo, e a Contagem da Coluna ValorTotal
print('-' * 10)
print('°•*⁀➷ Soma dos Produtos °•*⁀➷')
soma_produto = df_vendas.groupby('Produto')['ValorTotal'].sum()
print(soma_produto)
print('-' * 10)

print('°•*⁀➷ Media das Categorias °•*⁀➷')
media_categoria = df_vendas.groupby('Categoria')['ValorTotal'].mean()
print(media_categoria)
print('-' * 10)

print('°•*⁀➷ Maxima das Categorias °•*⁀➷')
Maximo_categoria = df_vendas.groupby('Categoria')['ValorTotal'].max()
print(Maximo_categoria)
print('-' * 10)

print('°•*⁀➷ Minimo das Categorias °•*⁀➷')
minimo_categoria = df_vendas.groupby('Categoria')['ValorTotal'].min()
print(minimo_categoria)
print('-' * 10)

print('°•*⁀➷ Numero de Vendas por Categoria °•*⁀➷')
numero_vendas = df_vendas.groupby('Categoria')['ValorTotal'].count()
print(numero_vendas)
print('-' * 10)
print('=' * 50)



