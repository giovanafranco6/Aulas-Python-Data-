import seaborn as sns
import matplotlib.pyplot as plt
import pandas as pd

# Criando um DataFrame 
dados={
    'idade': [19, 20, 20, 20, 21, 21, 21, 21, 22, 22, 22, 23, 24, 25, 28, 35]
}

df_alunos = pd.DataFrame(dados)

# Configurnaod o tema
sns.set_theme(style='whitegrid')

plt.figure(figsize=(10, 6))

sns.histplot(
    data=df_alunos, 
    x='idade', 
    kde=True,      
    color='darkorange',   
    bins=10         
)

plt.title('Distribuição de Idades na Turma de Python', fontsize=15)
plt.xlabel('Idades', fontsize=12)
plt.ylabel('Quantidade', fontsize=12)

plt.show()