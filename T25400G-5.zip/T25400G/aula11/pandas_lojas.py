import pandas as pd 

df = pd.read_csv("vendas_lojas.csv")

print("--- DataFrame Origina l---")
print(df)
print("-" * 50)
print()

print("--- 20 Primeiras Linhas ---")
print(df.head(20))
print("-" * 50)
print()

print("--- 15 Ultimas Linhas ---")
print(df.tail(15))
print("-" * 50)
print()

print("--- Informações do DataFrame ---")
print(df.info())
print("-" * 50)
print()


print("--- Informações do DataFrame ---")
print(df.info())
print("-" * 50)
print()

print("--- Descrição Estatistica ---")
print(df.describe())
print("-" * 50)
print()

print("--- Coluna 'Marca' (series) ---")
print(df["Marca"].head(20))
print("-" * 50)
print()

print("--- Vendas de Notebooks ---")
notebook = df["Categoria"] == 'Notebook'
print(df[notebook])
print("-" * 50)
print()

print("--- Vendas abaixo de 1000 reais ---")
vendas_menor_1000 = df["Preço Unitário"] <= 1000
print(df[vendas_menor_1000])
print("-" * 50)
print()

df["Data da Venda"] = pd.to_datetime(df["Data da Venda"])

print("--- Dados Apos a Conversao de Data ---")
print(df.info())
print("-" * 50)
print()


print("--- Vendas de 2016-01-10 ---")
vendas_dias_10_01 = df["Data da Venda"] == "2016-01-10"
print(df[vendas_dias_10_01])
print("-" * 50)
print()

print("--- Vendas de 2017 ---")
vendas_2017 = df["Data da Venda"].dt.year == 2017
print(df[vendas_2017])
print("-" * 50)
print()

print("--- Vendas ddo mes 7 de 2016 ---")
vendas_ano = df['Data da Venda'].dt.year == 2016
vendas_mes = df['Data da Venda'].dt.month == 7
mes_ano = df[vendas_ano & vendas_mes]
print(mes_ano)
print("-" * 50)
print()

print("--- Vendas do perido de JAneiro a Junho de 2018 ---")
inicial = df['Data da Venda'] >= "2018-01-01"
final = df['Data da Venda'] <= "2018-06-30"
print(df[inicial & final])
print("-" * 50)
print()

print("--- Criar coluna total da venda ---")
df["Total da Venda"] = df["Preço Unitário"] * df["Tamanho Pedido"]
print(df["Total da Venda"])
print("-" * 50)
print()


print("--- Vendas Totais por Categoria ---")
total_categoria = df.groupby("Categoria")["Total da Venda"].sum()
print(total_categoria)
print("-" * 50)
print()

